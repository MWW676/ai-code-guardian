import os
import json
import time
import logging
from google import genai
from google.genai import types
from google.genai.errors import APIError
from src.providers.llm_base import LLMProvider
from src.core.models import ReportModel

logger = logging.getLogger(__name__)
logger.setLevel(logging.WARNING)

class GeminiClient(LLMProvider):
    SYSTEM_PROMPT = """
    --- START SYSTEM INSTRUCTION ---

    You are a **Principal Software Engineer** and **Security Auditor** specializing in Python development and secure coding practices.
    Your task is to conduct a **comprehensive, multi-faceted code review** of the provided Git Diff. Your evaluation must go beyond simple syntax and cover maintainability, performance, and security.
    
    **Mandatory Procedure:**
    1.  **Analyze Holistically:** Evaluate the changes as if they were being merged into a production system.
    2.  **Apply Checklist:** Systematically apply the **Code Review Rubric and Weightage** provided below.
    3.  **Strict Output:** Your response must **strictly adhere** to the JSON Schema provided. Do not include the rubric, any prose, or Markdown tags outside of the JSON object itself.
    
    **[CODE REVIEW RUBRIC AND WEIGHTAGE START]**
    ### I. Code Correctness & Quality (Weight: 40%)
    * **W=15 - Logic & Functional Correctness:** Does the change implement the intended functionality correctly? Are all edge cases handled? Is the new/modified logic sound?
    * **W=15 - Error Handling & Robustness:** Are proper exceptions raised/caught? Are inputs validated (especially user/external data)? Are resources (files, connections) closed correctly?
    * **W=10 - Testability & Simplicity:** Is the code easily testable? Is the implementation overly complex or convoluted? Does it avoid unnecessary state or side effects?
    
    ### II. Maintainability & Readability (Weight: 30%)
    * **W=10 - Naming & Clarity:** Are variables, functions, and classes clearly and accurately named? Is the intent of the code immediately obvious?
    * **W=10 - Documentation & Comments:** Are complex areas sufficiently commented? Are docstrings (where applicable) accurate and up-to-date?
    * **W=10 - Style & Idioms (PEP 8/Best Practices):** Does the code follow standard style guides (e.g., PEP 8 for Python)? Are language-specific idioms (e.g., list comprehensions, context managers) used effectively?
    
    ### III. Performance & Efficiency (Weight: 10%)
    * **W=5 - Algorithmic Efficiency:** Are there potential *O(n)* issues? Are loop operations optimized (e.g., avoiding expensive calls inside loops)?
    * **W=5 - Resource Use:** Is memory/CPU usage considered for large inputs? Are necessary imports and minimal dependencies maintained?
    
    ### IV. Security & Vulnerabilities (Weight: 20%)
    * **W=10 - Input Sanitization & Trust Boundaries:** Is external input (e.g., API parameters, file contents) sanitized before use in database queries, file paths, or shell commands (e.g., prevention of **SQL Injection, Path Traversal, OS Command Injection**)?
    * **W=5 - Sensitive Data Handling:** Is sensitive information (passwords, tokens, PII) handled securely, avoiding logs/comments/diffs? Are secrets hardcoded?
    * **W=5 - Dependency Changes:** If dependencies are added/updated, are there any known vulnerabilities associated with the new version or package?
    
    **[CODE REVIEW RUBRIC AND WEIGHTAGE END]**
    
    [JSON SCHEMA BEGIN]
    {json.dumps(review_schema_dict, indent=2)}
    [JSON SCHEMA END]
    
    --- END SYSTEM INSTRUCTION ---
    """

    def __init__(self, api_key: str):
        if not api_key:
            raise EnvironmentError("GEMINI_API_KEY not found SSM configs.")
        self.client = genai.Client(api_key=api_key)
        self.model_name = "gemini-2.5-flash"

        # --- Define Known Limits ---
        self._MAX_RPD: int = 20
        self._MAX_TPM: int = 250_000
        self._max_output_tokens = 6000
        # --- Global Tracking Variables ---
        self.DAILY_REQUEST_COUNT: int = 0
        self.LAST_REQUEST_TIME: float = time.time()
        self.CURRENT_MINUTE_TOKEN_COUNT: int = 0

    def check_and_reset_limits(self, contents: str):
        """
        1. Checks the time and resets the RPD or TPM counters if necessary.
        2. Checks token count to ensure its below threshold.
        """
        now = time.time()
        elapsed_minutes = (now - self.LAST_REQUEST_TIME) / 60
        elapsed_days = (now - self.LAST_REQUEST_TIME) / (60 * 60 * 24)

        # 1. Reset TPM/RPM counter if a minute has passed
        if elapsed_minutes >= 1:
            logger.info(f"Resetting TPM count (last minute total: {self.CURRENT_MINUTE_TOKEN_COUNT} tokens).")
            self.CURRENT_MINUTE_TOKEN_COUNT = 0
            self.LAST_REQUEST_TIME = now

        # 2. Reset RPD counter if a day has passed
        if elapsed_days >= 1:
            logger.info(f"Resetting RPD count (last day total: {self.DAILY_REQUEST_COUNT} requests).")
            self.DAILY_REQUEST_COUNT = 0

        # 3. RPD Check (Most critical for free tier)
        if self.DAILY_REQUEST_COUNT >= self._MAX_RPD:
            logger.warning(f"[LIMIT EXCEEDED] RPD limit of {self._MAX_RPD} reached. Skipping API call.")
            return False

        # 4. TPM Check (Pre-calculate input cost)
        input_tokens = len(contents) / 4
        potential_total_tokens = input_tokens + self._max_output_tokens

        if self.CURRENT_MINUTE_TOKEN_COUNT + potential_total_tokens > self._MAX_TPM:
            logger.warning(f"TPM limit would be exceeded. Skipping API call.")
            return False

        # 5. Always update the last request time
        self.LAST_REQUEST_TIME = now
        return True

    def generate_system_instruction(self) -> str:
        # Construct prompt
        schema_dict = ReportModel.model_json_schema()
        schema_str = json.dumps(schema_dict, indent=2)

        sys_instruction = f"""
        {self.SYSTEM_PROMPT}
        
        ### IMPORTANT RULES:
        1. You are a STRICT code reviewer. Do not summarize changes. Find BUGS and RISKS.
        2. If the code is just formatting changes or perfectly fine, return risk_score: 0.
        3. Your Output MUST be a valid JSON object matching the schema below.

        ### OUTPUT JSON SCHEMA:
        {schema_str}
        """
        return sys_instruction

    def analyze_diff(self, contents: str) -> dict:
        """Generates content through Gemini open api call."""
        sys_instruction = self.generate_system_instruction()
        user_message = f"""
        Please analyze the following Git Diff:
        
        [GIT DIFF START]
        {contents}
        [GIT DIFF END]
        """

        if not self.check_and_reset_limits(contents=user_message):
            logger.warning("Limit or token quota check failed.")
            return {"status":"SKIPPED", "reason": "Rate/Token limit exceeded."}

        try:
            logger.info(f"Evaluating code diff with model: {self.model_name}...")
            config_object = types.GenerateContentConfig(
                max_output_tokens=self._max_output_tokens,
                response_mime_type="application/json",
                system_instruction=sys_instruction,
                temperature=0.1
            )

            response = self.client.models.generate_content(
                model=self.model_name,
                contents=user_message,
                config=config_object,
            )

            self.DAILY_REQUEST_COUNT += 1
            actual_total_tokens = response.usage_metadata.total_token_count
            self.CURRENT_MINUTE_TOKEN_COUNT += actual_total_tokens

            # Build dict from resp
            raw_text = response.text
            clean_json_str = raw_text.replace("```json", "").replace("```", "").strip()

            try:
                ai_result = json.loads(clean_json_str)
            except json.JSONDecodeError:
                logger.error(f"Failed to parse JSON: {raw_text}")
                ai_result = {"status": "ERROR", "error": raw_text}

            resp_dict = {
                "result": ai_result,
                "status": ai_result.get('status'),
                "timestamp": time.time(),
                "token_used": response.usage_metadata.total_token_count if response.usage_metadata else 0
            }
            return resp_dict

        except APIError as e:
            logger.error(f"An error occurred during the API call: {e}")
            return {"status":"ERROR", "error": str(e)}
        except Exception as e:
            logger.error(f"Unexpected error: {e}")
            return {"status":"ERROR", "error": str(e)}
