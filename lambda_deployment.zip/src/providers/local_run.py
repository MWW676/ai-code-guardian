import boto3
from botocore.exceptions import ClientError
import logging

logging.basicConfig(level=logging.INFO)


def test_aws_credentials():
    """
    Checks if boto3 can successfully assume an identity using default credentials.
    """
    try:
        # Boto3 will automatically look up the credentials chain here.
        sts_client = boto3.client('sts')

        # Calling get_caller_identity is a minimal, cheap way to verify auth.
        response = sts_client.get_caller_identity()

        print("\n✅ Credentials Test Successful!")
        print("-" * 30)
        print(f"User ARN: {response.get('Arn')}")
        print(f"Account ID: {response.get('Account')}")

    except ClientError as e:
        # If credentials are not found or are invalid, a ClientError is raised.
        error_code = e.response['Error']['Code']

        if error_code == 'InvalidClientTokenId':
            print("\n❌ FAILED: Invalid or expired credentials found.")
            print("Action: Check your Access Key ID and Secret Access Key.")

        elif error_code == 'NoCredentialsError':
            print("\n❌ FAILED: No credentials found in any standard location.")
            print("Action: Ensure ~/.aws/credentials file exists and is populated.")

        else:
            print(f"\n❌ FAILED: An unexpected AWS error occurred: {error_code}")

    except Exception as e:
        print(f"\n❌ FAILED: A non-AWS error occurred: {e}")

def test_split(s):
    print(s.split())

if __name__ == "__main__":
    s = ' How many  hours do  you   sleep! a  '
    test_split(s)
    {
        "diff_text": "diff --git a/src/providers/gemini_client.py b/src/providers/gemini_client.py\nindex df12f64..6dac777 100644\n--- a/src/providers/gemini_client.py\n+++ b/src/providers/gemini_client.py\n@@ -7,12 +7,18 @@ from google import genai\n from google.genai import types\n from google.genai.errors import APIError\n from src.providers.llm_base import LLMProvider\n+from src.providers.review_schema import REVIEW_SCHEMA\n \n logger = logging.getLogger(__name__)\n logger.setLevel(logging.WARNING)\n \n class GeminiClient(LLMProvider):\n-    \"\"\"Gemini openapi client to process llm prompts.\"\"\"\n+    SYSTEM_PROMPT = \"\"\"\n+    You are a Senior Tech Lead and security auditor.\n+    Your task is to analyze the provided Git Diff to identify potential bugs, security vulnerabilities, and code that does not conform to Python PEP8 specifications.\n+    Your responses must strictly adhere to the JSON Schema below and cannot contain any additional prose or Markdown tags (such as ```json`).\n+    \"\"\"\n+\n     def __init__(self):\n         api_key = os.environ.get('GEMINI_API_KEY')\n         if not api_key:\n@@ -69,12 +75,28 @@ class GeminiClient(LLMProvider):\n \n     def analyze_diff(self, contents: str) -> dict:\n         \"\"\"Generates content through Gemini open api call.\"\"\"\n-        if not self.check_and_reset_limits(contents=contents):\n+        # Construct prompt\n+        final_prompt = f\"\"\"\n+        --- START SYSTEM INSTRUCTION ---\n+        {self.SYSTEM_PROMPT}\n+        \n+        [JSON SCHEMA BEGIN]\n+        {json.dumps(REVIEW_SCHEMA, indent=2)}\n+        [JSON SCHEMA END]\n+        --- END SYSTEM INSTRUCTION ---\n+        \n+        Please start to analyze the following code diff:\n+        [GIT DIFF CONTENT START]\n+        {contents}\n+        [GIT DIFF CONTENT END]\n+        \"\"\"\n+\n+        if not self.check_and_reset_limits(contents=final_prompt):\n             logger.warning(\"Limit or token quota check failed.\")\n             return {\"status\":\"SKIPPED\", \"reason\": \"Rate/Token limit exceeded.\"}\n \n         try:\n-            logger.info(f\"Calculating score with model: {self.model_name}...\")\n+            logger.info(f\"Evaluating code diff with model: {self.model_name}...\")\n \n             config_object = types.GenerateContentConfig(\n                 max_output_tokens=self._max_output_tokens,\ndiff --git a/src/providers/review_schema.py b/src/providers/review_schema.py\nindex 01de689..909df22 100644\n--- a/src/providers/review_schema.py\n+++ b/src/providers/review_schema.py\n@@ -1,7 +1,6 @@\n-\n-{\n+REVIEW_SCHEMA = {\n     \"status\": \"PASS\" | \"FAIL\" | \"NEEDS_ATTENTION\",\n-    \"risk_score\": 0,\n+    \"risk_score\": 0, # 0-100\n     \"comments\": [\n         {\n             \"severity\": \"CRITICAL\" | \"MINOR\" | \"INFO\",
